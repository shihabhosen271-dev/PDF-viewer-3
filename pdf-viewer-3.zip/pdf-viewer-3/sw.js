const C='pdf-viewer-3-v1';
const ASSETS=['./pdfjs/pdf.min.mjs','./pdfjs/pdf.worker.min.mjs','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/maskable-512.png'];
const PAGE='./index.html';
// A response that went through a redirect cannot be served for a navigation, so rebuild a clean copy.
async function clean(res){return new Response(await res.clone().blob(),{status:200,headers:{'Content-Type':'text/html; charset=utf-8'}})}
async function fetchPage(){const r=await fetch('./',{cache:'reload'});if(!r.ok)throw 0;return clean(r)}
self.addEventListener('install',e=>{e.waitUntil((async()=>{const c=await caches.open(C);await c.put(PAGE,await fetchPage());await Promise.all(ASSETS.map(a=>c.add(a).catch(()=>{})));self.skipWaiting()})())});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const req=e.request;if(req.method!=='GET')return;
 const url=new URL(req.url);if(url.origin!==location.origin)return;
 if(req.mode==='navigate'){
  e.respondWith((async()=>{const c=await caches.open(C);
   try{const r=await fetch(req);if(r.ok&&!r.redirected){c.put(PAGE,await clean(r))}else if(r.ok){c.put(PAGE,await clean(r))}return r}
   catch(err){const m=await c.match(PAGE);return m||new Response('অফলাইন: অ্যাপ একবার ইন্টারনেটে খুলুন',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}})}})());
  return}
 e.respondWith(caches.match(req,{ignoreSearch:true}).then(r=>r||fetch(req).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(req,cp))}return res})));
});
