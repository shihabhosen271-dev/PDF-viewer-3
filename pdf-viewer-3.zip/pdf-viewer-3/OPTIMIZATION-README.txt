ছবি শিট — Performance Optimization Phase 3

এই প্যাকেজে:
- ছবির মূল ডেটা ও Thumbnail আলাদা IndexedDB Blob Store-এ সংরক্ষণ
- PDF পৃষ্ঠা Base64 Data URL না বানিয়ে Blob URL হিসেবে তৈরি
- পুরোনো Base64 ডেটা প্রথম চালুর পর ধাপে ধাপে Blob Storage-এ স্থানান্তর
- Cell পরিবর্তন অনুযায়ী IndexedDB-তে Incremental Save
- ব্যাকআপ নেওয়ার সময় Blob URL-কে Data URL-এ রূপান্তর, যাতে JSON ব্যাকআপ বহনযোগ্য থাকে
- IndexedDB schema version 4 এবং Service Worker cache version 21

আপডেট করার আগে:
1. বর্তমান অ্যাপ থেকে একটি Backup JSON ডাউনলোড করুন।
2. আগের অ্যাপের একই ডোমেইন/অরিজিনে নতুন ফাইলগুলো প্রকাশ করুন, যাতে IndexedDB ডেটা একই থাকে।
3. প্রথমবার নতুন সংস্করণ খুলে Migration শেষ হওয়া পর্যন্ত অ্যাপ বন্ধ করবেন না।
4. Migration চলাকালে পর্যাপ্ত ফ্রি স্টোরেজ রাখুন।
5. Backup/Restore পরীক্ষা না করে পুরোনো ডেটা বা অ্যাপের Storage মুছবেন না।

নোট:
- এই প্যাকেজে JavaScript syntax ও ZIP integrity যাচাই করা হয়েছে।
- বাস্তব Android ডিভাইসে RAM/CPU benchmark বা সম্পূর্ণ end-to-end browser test করা হয়নি।
- ১০০ MB PDF খোলার সময় PDF.js-কে মূল PDF বাফার প্রসেস করতে হয়; Blob Storage মূলত PDF পৃষ্ঠা রূপান্তরের পরের স্থায়ী Base64/State overhead কমায়। এটি PDF.js-এর প্রাথমিক parsing memory সম্পূর্ণ দূর করে না।


- Backup now exports a ZIP containing a small JSON manifest and original image/thumbnail Blobs as separate binary entries.
- No Base64 expansion or one giant JSON.stringify over all image bytes during backup.
- Restore accepts both old JSON backups and new ZIP backups.
- ZIP entries use STORE (no compression) to minimize CPU/RAM and support large image files.
- Tested inline JavaScript syntax and ZIP archive integrity of the app package. Real Android device backup/restore benchmark remains necessary.


- "ব্যাকআপ" বাটন এখন একটি .json ফাইল (chobi-backup-YYYY-MM-DD.json) ডাউনলোড করে।
- ছবি একটি একটি করে Data URL-এ রূপান্তর হয় এবং সাথে সাথে Blob-এ রাখা হয়, তাই একসাথে বিশাল String তৈরি হয় না।
- Restore পুরোনো .json এবং .zip দুই ধরনের ব্যাকআপই খুলতে পারে।
- Service Worker cache version 23।


- নাম বদলালে সাথে সাথে হেডার ও ব্রাউজার ট্যাবের নাম বদলায়; সেভ ধীর বা ব্যর্থ হলেও নাম আটকে থাকে না।
- নাম লেখার ডায়ালগ মোবাইল কীবোর্ডের জন্য ঠিক করা হয়েছে (কীবোর্ডের উপরে দেখায়, Enter ঠিকভাবে কাজ করে)।
- Service Worker cache version 24।
